import * as React from 'react';
import { useState, useEffect, useRef } from 'react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';
import {
    QrCode, Search, Camera, Package, User, AlertCircle, CheckCircle2,
    RotateCcw, Trash2, Save, History, RefreshCw, ChevronRight, X, AlertTriangle, ArrowRight
} from 'lucide-react';
import { Html5QrcodeScanner, Html5Qrcode } from 'html5-qrcode';
import { isDemoMode } from '../utils/environment';
import ReportIssueModal from '../components/ReportIssueModal';

interface RTSReport {
    id: string;
    trackingNumber: string;
    status: string;
    customerName: string;
    actionType: string;
    productCode?: string;
    notes: string;
    photoUrl: string;
    timestamp: number;
    reportedBy: string;
}

const STATUS_OPTIONS = [
    { value: 'checked', label: 'เช็คพัสดุแล้ว (OK)', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    { value: 'rts_received', label: 'รับสินค้าตีกลับ (RTS)', color: 'bg-amber-50 text-amber-700 border-amber-200' },
    { value: 'damaged', label: 'สินค้าเสียหาย', color: 'bg-rose-50 text-rose-700 border-rose-200' },
    { value: 'cancelled', label: 'ยกเลิกรายการ', color: 'bg-slate-100 text-slate-700 border-slate-300' },
];

const ACTION_OPTIONS = [
    { value: 'resend_original', label: 'ส่งสินค้าเดิมกลับไป', icon: RotateCcw },
    { value: 'new_production', label: 'ขอผลิตสินค้าใหม่ (เคลม)', icon: RefreshCw },
    { value: 'restock', label: 'เก็บเข้าสต็อกเพื่อขายใหม่', icon: Package },
    { value: 'refund', label: 'คืนเงินลูกค้า', icon: Save },
];

const RTSManagementPage: React.FC = () => {
    const { shipments } = useData();
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState<'scan' | 'search' | 'history'>('search');
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedShipment, setSelectedShipment] = useState<any>(null);
    const [reports, setReports] = useState<RTSReport[]>([]);

    const [scanResult, setScanResult] = useState<string | null>(null);
    const [trackHistory, setTrackHistory] = useState<RTSReport[]>([]);

    // Modal State
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);

    const formRef = useRef<HTMLDivElement>(null);

    const [isScanning, setIsScanning] = useState(false);
    const scannerRef = useRef<Html5QrcodeScanner | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const isSecureContext = window.isSecureContext;

    // Unused constants removed (STATUS_OPTIONS, ACTION_OPTIONS were local)
    const getConnectionStatus = () => {
        if (isDemoMode()) return { text: 'Demo Mode', color: 'bg-amber-100 text-amber-700' };
        if (isSecureContext) return { text: 'Secure Connection', color: 'bg-emerald-100 text-emerald-700' };
        return { text: 'Insecure (Camera Restricted)', color: 'bg-rose-100 text-rose-700' };
    };

    // Load History
    const fetchHistory = async () => {
        try {
            const res = await fetch('/api/rts');
            if (res.ok) {
                const data = await res.json();
                setReports(data || []);
            }
        } catch (e) {
            console.error('Failed to fetch RTS history', e);
        }
    };

    useEffect(() => {
        fetchHistory();
    }, []);

    const startScanner = () => {
        if (!isSecureContext && !isDemoMode()) {
            // Fallback for HTTP NAS: Click hidden file input
            fileInputRef.current?.click();
            return;
        }

        if (!scannerRef.current) {
            const scanner = new Html5QrcodeScanner(
                "reader",
                { fps: 15, qrbox: { width: 250, height: 250 } },
                false
            );
            scanner.render(onScanSuccess, onScanFailure);
            scannerRef.current = scanner;
            setIsScanning(true);
        }
    };

    // Handle file scan result
    const handleFileScan = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const html5QrCode = new Html5Qrcode("reader");
        html5QrCode.scanFile(file, true)
            .then(decodedText => {
                onScanSuccess(decodedText);
            })
            .catch(err => {
                alert("ไม่สามารถอ่านบาร์โค้ดจากรูปภาพได้");
                console.error("File scan error", err);
            });
    };

    const stopScanner = async () => {
        if (scannerRef.current) {
            try {
                await scannerRef.current.clear();
                scannerRef.current = null;
                setIsScanning(false);
            } catch (e) {
                console.error("Failed to clear scanner", e);
            }
        }
    };

    useEffect(() => {
        return () => {
            stopScanner();
        };
    }, []);

    // Also stop if tab changes
    useEffect(() => {
        if (activeTab !== 'scan') {
            stopScanner();
        }
    }, [activeTab]);

    function onScanSuccess(decodedText: string) {
        setScanResult(decodedText);
        handleFindShipment(decodedText);
        stopScanner(); // Auto stop once found to clear UI
    }

    function onScanFailure(error: any) {
        // Quiet failure
    }

    const handleFindShipment = async (tracking: string) => {
        const found = shipments.find(s => s.trackingNumber === tracking || s.id === tracking);
        if (found) {
            setSelectedShipment(found);
            // Fetch history for this specific tracking
            try {
                const res = await fetch(`/api/rts/${found.trackingNumber}`);
                if (res.ok) {
                    const historyData = await res.json();
                    setTrackHistory(historyData);
                }
            } catch (e) {
                console.error("Failed to load track history", e);
            }

            // Scroll to form on mobile
            if (window.innerWidth < 1024) {
                formRef.current?.scrollIntoView({ behavior: 'smooth' });
            }
        } else {
            alert(`ไม่พบข้อมูลพัสดุเลขที่: ${tracking}`);
        }
    };

    // Old form handlers removed as they are now in ReportIssueModal

    const filteredShipments = searchTerm.length > 2
        ? shipments.filter(s =>
            s.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            s.trackingNumber?.toLowerCase().includes(searchTerm.toLowerCase())
        ).slice(0, 5)
        : [];

    return (
        <div className="space-y-6 pb-12 animate-fade-in">
            {/* Header */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                <div className="flex items-center space-x-3">
                    <div className="bg-slate-900 p-2 rounded-xl text-white shadow-lg">
                        <Package className="w-6 h-6" />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-slate-800">ค้นหาพัสดุ (Search & Scan)</h1>
                        <p className="text-sm text-slate-500 font-medium">สแกนเลขพัสดุหรือค้นหาชื่อเพื่อตรวจสอบสถานะ</p>
                    </div>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex bg-white p-1 rounded-2xl border border-slate-200 shadow-sm w-fit">
                <button
                    onClick={() => setActiveTab('search')}
                    className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-all ${activeTab === 'search' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
                >
                    <Search className="w-4 h-4" />
                    ค้นหารายชื่อ
                </button>
                <button
                    onClick={() => setActiveTab('scan')}
                    className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-all ${activeTab === 'scan' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
                >
                    <QrCode className="w-4 h-4" />
                    สแกนกล้อง
                </button>
                <button
                    onClick={() => setActiveTab('history')}
                    className={`flex items-center gap-2 px-6 py-2.5 rounded-xl font-bold transition-all ${activeTab === 'history' ? 'bg-slate-900 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
                >
                    <History className="w-4 h-4" />
                    ประวัติรายงาน
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Side: Scanning or Search */}
                <div className="space-y-6">
                    {activeTab === 'scan' && (
                        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-xl overflow-hidden text-center animate-fade-in">
                            {!isScanning ? (
                                <div className="py-8 sm:py-12 space-y-6">
                                    <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold mb-4 ${getConnectionStatus().color}`}>
                                        <AlertCircle className="w-3 h-3" />
                                        {getConnectionStatus().text}
                                    </div>
                                    <div className="w-20 h-20 sm:w-24 sm:h-24 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                                        <Camera className="w-8 h-8 sm:w-10 sm:h-10" />
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-black text-slate-800">พร้อมสแกนพัสดุ</h3>
                                        <p className="text-slate-400 font-medium max-w-[280px] mx-auto mt-2 text-sm">
                                            {!isSecureContext && !isDemoMode()
                                                ? "ระบบตรวจพบการเชื่อมต่อแบบ HTTP (ไม่ปลอดภัย) จึงไม่สามารถเปิดกล้องได้โดยตรง กรุณาใช้ไฟล์ภาพแทน"
                                                : "กดปุ่มด้านล่างเพื่อเริ่มเปิดกล้องสแกนบาร์โค้ดหน้ากล่อง"
                                            }
                                        </p>
                                    </div>

                                    <input
                                        type="file"
                                        accept="image/*"
                                        ref={fileInputRef}
                                        className="hidden"
                                        onChange={handleFileScan}
                                    />

                                    {/* Primary Button based on Context */}
                                    {!isSecureContext && !isDemoMode() ? (
                                        <button
                                            onClick={() => fileInputRef.current?.click()}
                                            className="w-full sm:w-auto bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-700 hover:to-indigo-600 text-white px-8 py-5 rounded-2xl font-black text-lg shadow-xl shadow-indigo-200 transition-all active:scale-95 flex items-center justify-center gap-3 animate-pulse"
                                        >
                                            <Camera className="w-6 h-6" />
                                            ถ่ายรูป/อัปโหลดรูป
                                        </button>
                                    ) : (
                                        <button
                                            onClick={startScanner}
                                            className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-5 rounded-2xl font-black text-lg shadow-xl shadow-indigo-200 transition-all active:scale-95 flex items-center justify-center gap-3 animate-pulse"
                                        >
                                            <QrCode className="w-6 h-6" />
                                            เริ่มสแกนกล้อง
                                        </button>
                                    )}

                                    {/* Fallback note */}
                                    {!isSecureContext && !isDemoMode() && (
                                        <p className="text-xs text-slate-400 mt-4">
                                            *แนะนำให้ถ่ายรูป Close-up ที่บาร์โค้ดให้ชัดเจน
                                        </p>
                                    )}
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <h3 className="font-black text-slate-800 flex items-center gap-2">
                                            <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></div>
                                            กำลังเปิดกล้อง...
                                        </h3>
                                        <button
                                            onClick={stopScanner}
                                            className="text-rose-500 text-sm font-bold hover:underline"
                                        >
                                            ปิดกล้อง
                                        </button>
                                    </div>
                                    <div id="reader" className="overflow-hidden rounded-2xl border-4 border-slate-900 bg-slate-50 aspect-square"></div>
                                </div>
                            )}

                            {scanResult && (
                                <div className="mt-6 p-4 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center justify-between animate-scale-up">
                                    <div className="flex items-center gap-3">
                                        <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                                        <div className="text-left">
                                            <p className="text-[10px] uppercase font-black text-emerald-600 tracking-widest">SCANNED RESULT</p>
                                            <p className="font-mono font-bold text-slate-700">{scanResult}</p>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => setScanResult(null)}
                                        className="p-1 hover:bg-emerald-100 rounded-lg"
                                    >
                                        <X className="w-4 h-4 text-emerald-400" />
                                    </button>
                                </div>
                            )}
                        </div>
                    )}

                    {activeTab === 'search' && (
                        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                            <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                                <input
                                    type="text"
                                    placeholder="ค้นหา Tracking หรือ ชื่อลูกค้า..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-slate-900 outline-none font-medium"
                                />
                            </div>

                            <div className="space-y-2">
                                {filteredShipments.map(s => (
                                    <div
                                        key={s.id}
                                        onClick={() => setSelectedShipment(s)}
                                        className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-center justify-between group ${selectedShipment?.id === s.id ? 'bg-slate-900 border-slate-900 text-white' : 'bg-white border-slate-100 hover:border-slate-300'}`}
                                    >
                                        <div className="flex items-center gap-3">
                                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${selectedShipment?.id === s.id ? 'bg-white/10' : 'bg-slate-100'}`}>
                                                <User className={`w-5 h-5 ${selectedShipment?.id === s.id ? 'text-white' : 'text-slate-500'}`} />
                                            </div>
                                            <div>
                                                <p className="font-bold">{s.customerName}</p>
                                                <p className={`text-xs ${selectedShipment?.id === s.id ? 'text-white/60' : 'text-slate-400'}`}>{s.trackingNumber}</p>
                                            </div>
                                        </div>
                                        <ChevronRight className={`w-5 h-5 transition-transform group-hover:translate-x-1 ${selectedShipment?.id === s.id ? 'text-white/40' : 'text-slate-300'}`} />
                                    </div>
                                ))}
                                {searchTerm.length > 2 && filteredShipments.length === 0 && (
                                    <div className="text-center py-8 text-slate-400">
                                        <AlertCircle className="w-8 h-8 mx-auto mb-2 opacity-20" />
                                        <p className="text-sm font-bold">ไม่พบข้อมูล</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {activeTab === 'history' && (
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col max-h-[700px]">
                            <div className="p-5 bg-slate-50 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
                                <h3 className="font-black text-slate-800 flex items-center gap-2">
                                    <History className="w-5 h-5 text-indigo-600" />
                                    Track Filler (ประวัติการรายงาน)
                                </h3>
                                <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
                                    <button onClick={() => setSearchTerm('')} className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${!searchTerm ? 'bg-indigo-600 text-white' : 'bg-white text-slate-500 border border-slate-200'}`}>ทั้งหมด</button>
                                    <button onClick={() => setSearchTerm('ตีกลับ')} className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${searchTerm === 'ตีกลับ' ? 'bg-amber-500 text-white' : 'bg-white text-slate-500 border border-slate-200'}`}>RTS เท่านั้น</button>
                                    <button onClick={() => setSearchTerm('เสียหาย')} className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${searchTerm === 'เสียหาย' ? 'bg-rose-500 text-white' : 'bg-white text-slate-500 border border-slate-200'}`}>เสียหาย</button>
                                </div>
                            </div>

                            <div className="p-4 border-b border-slate-100 bg-white">
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                                    <input
                                        type="text"
                                        placeholder="เครื่องกรองข้อมูล: ค้นหา SKU, ชื่อ, หรือสถานะ..."
                                        className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>
                            </div>

                            <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
                                {reports.filter(r =>
                                    !searchTerm ||
                                    r.trackingNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                    r.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                    r.actionType?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                    r.productCode?.toLowerCase().includes(searchTerm.toLowerCase())
                                ).map(r => (
                                    <div key={r.id} className="p-4 bg-white rounded-2xl border border-slate-100 shadow-sm hover:border-indigo-200 transition-all flex gap-4 group">
                                        <div className="relative shrink-0">
                                            {r.photoUrl ? (
                                                <img src={r.photoUrl} className="w-20 h-20 rounded-xl object-cover border border-slate-100 shadow-sm" alt="RTS" />
                                            ) : (
                                                <div className="w-20 h-20 rounded-xl bg-slate-50 flex items-center justify-center text-slate-300 border border-slate-100">
                                                    <Package className="w-8 h-8 opacity-20" />
                                                </div>
                                            )}
                                            <div className="absolute -bottom-1 -right-1 bg-white p-1 rounded-lg border border-slate-100 shadow-sm">
                                                <Camera className="w-3 h-3 text-slate-400" />
                                            </div>
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                                                <h4 className="font-bold text-slate-800 text-sm truncate">{r.trackingNumber}</h4>
                                                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase border ${r.actionType?.includes('เสียหาย') ? 'bg-rose-50 text-rose-600 border-rose-100' :
                                                    r.actionType?.includes('ตีกลับ') ? 'bg-amber-50 text-amber-600 border-amber-100' :
                                                        'bg-indigo-50 text-indigo-600 border-indigo-100'
                                                    }`}>
                                                    {r.actionType || 'REPORTED'}
                                                </span>
                                            </div>
                                            <div className="flex items-center gap-2 mb-2">
                                                <p className="text-xs font-bold text-slate-600 truncate">{r.customerName}</p>
                                                <span className="text-slate-300 text-xs">•</span>
                                                <p className="text-[10px] font-mono font-bold text-indigo-500 bg-indigo-50/50 px-1.5 py-0.5 rounded-md">
                                                    SKU: {r.productCode || 'N/A'}
                                                </p>
                                            </div>
                                            <div className="flex items-center justify-between mt-auto pt-2 border-t border-slate-50">
                                                <p className="text-[10px] text-slate-400 flex items-center gap-1">
                                                    <RotateCcw className="w-3 h-3" />
                                                    {new Date(r.timestamp).toLocaleDateString('th-TH')} {new Date(r.timestamp).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' })}
                                                </p>
                                                <p className="text-[10px] font-black text-slate-300 uppercase tracking-tighter">By {r.reportedBy}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                                {reports.length === 0 && (
                                    <div className="text-center py-20 opacity-20">
                                        <History className="w-16 h-16 mx-auto mb-4" />
                                        <p className="font-black text-xl">ไม่มีประวัติการรายงาน</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                {/* Right Side: Reporting Form */}
                <div className="space-y-6">
                    {selectedShipment ? (
                        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6 animate-slide-up">
                            <div className="relative group">
                                <button
                                    type="button"
                                    onClick={() => setSelectedShipment(null)}
                                    className="absolute -right-2 -top-2 bg-slate-200 text-slate-500 p-2 rounded-full shadow-sm hover:bg-slate-300 transition-colors z-10"
                                >
                                    <X className="w-4 h-4" />
                                </button>
                                <div className="bg-slate-900 rounded-2xl p-6 text-white relative overflow-hidden">
                                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16 blur-2xl"></div>
                                    <div className="relative z-10 flex flex-col gap-4">
                                        <div className="flex items-center gap-3">
                                            <div className="bg-white/20 p-2 rounded-lg">
                                                <User className="w-5 h-5" />
                                            </div>
                                            <div>
                                                <p className="text-[10px] uppercase font-black tracking-widest text-slate-400">CUSTOMER INFO</p>
                                                <h4 className="text-xl font-bold">{selectedShipment.customerName}</h4>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <p className="text-[10px] uppercase font-black tracking-widest text-slate-400">TRACKING</p>
                                                <p className="font-mono font-bold text-lg">{selectedShipment.trackingNumber}</p>
                                            </div>
                                            <div>
                                                <p className="text-[10px] uppercase font-black tracking-widest text-slate-400">STATUS</p>
                                                <p className="font-bold text-emerald-400 text-lg">{selectedShipment.status}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Track History Mini View */}
                            {trackHistory.length > 0 && (
                                <div className="bg-slate-50 border border-slate-200 rounded-2xl overflow-hidden">
                                    <div className="bg-slate-100 px-4 py-2 text-[10px] font-black text-slate-500 uppercase flex items-center gap-2">
                                        <History className="w-3 h-3" />
                                        ประวัติการดำเนินการ (History)
                                    </div>
                                    <div className="p-3 space-y-2 max-h-40 overflow-y-auto">
                                        {trackHistory.map((h) => (
                                            <div key={h.id} className="text-xs flex gap-2 border-b border-slate-100 last:border-0 pb-2">
                                                <div className={`w-1.5 h-1.5 rounded-full mt-1 shrink-0 ${h.status.includes('damage') ? 'bg-rose-500' : 'bg-indigo-500'}`}></div>
                                                <div>
                                                    <p className="font-bold text-slate-700">{h.actionType} <span className="text-slate-400 font-normal">({h.status})</span></p>
                                                    <p className="text-[10px] text-slate-400">{new Date(h.timestamp).toLocaleString('th-TH')}</p>
                                                    {h.actionType && <span className="inline-block px-1.5 py-0.5 rounded bg-slate-200 text-[9px] font-bold text-slate-600 mt-1">{h.actionType}</span>}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Actions Area */}
                            <div className="pt-4 border-t border-slate-100">
                                <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2">
                                    <AlertTriangle className="w-5 h-5 text-amber-500" />
                                    จัดการพัสดุ (Actions)
                                </h4>
                                <div className="grid grid-cols-1 gap-3">
                                    <button
                                        onClick={() => setIsReportModalOpen(true)}
                                        className="w-full py-4 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all group"
                                    >
                                        <AlertTriangle className="w-5 h-5 group-hover:scale-110 transition-transform" />
                                        แจ้งปัญหา / ตีกลับ / เคลม
                                    </button>

                                    {/* Future extensions: e.g., Print Label, Edit Info */}
                                </div>
                            </div>

                        </div>
                    ) : (
                        <div ref={formRef} className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center flex flex-col items-center justify-center h-full min-h-[400px]">
                            <div className="bg-white p-4 rounded-full shadow-sm mb-4">
                                <Package className="w-12 h-12 text-slate-300" />
                            </div>
                            <h3 className="text-xl font-black text-slate-400">ยังไม่เลือกพัสดุ</h3>
                            <p className="text-sm text-slate-400 max-w-[200px] mt-2">กรุณาสแกนหรือค้นหาผู้รับ เพื่อเริ่มทำการเช็คสินค้าหรือรายงาน RTS</p>
                        </div>
                    )}
                </div>
            </div>

            {/* Modal */}
            {selectedShipment && (
                <ReportIssueModal
                    isOpen={isReportModalOpen}
                    onClose={() => setIsReportModalOpen(false)}
                    shipment={selectedShipment}
                    onSuccess={() => {
                        fetchHistory();
                        setActiveTab('history');
                        // Optional: Clear selection or show success via toast
                    }}
                />
            )}

        </div>
    );
};

export default RTSManagementPage;
